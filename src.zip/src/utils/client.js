const { CustomClient } = require('./index');
const client = new CustomClient();

module.exports = client;